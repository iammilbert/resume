
<?php
$conn = mysqli_connect("localhost", "darltran_duser", "Milbert@19950727", "darltran_dbase");
?>